package testfile;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import example.PracticeFormPage;

public class PracticeFormTest {
    WebDriver driver;
    PracticeFormPage formPage;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://demoqa.com/automation-practice-form");
        formPage = new PracticeFormPage(driver);
    }

    @Test
    public void testFormSubmission() {
        formPage.fillForm();
        // You can add assertions here to verify the success modal
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}
