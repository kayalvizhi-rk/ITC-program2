package example;



import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

public class PracticeFormPage {
    WebDriver driver;

    public PracticeFormPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    By firstName = By.id("firstName");
    By lastName = By.id("lastName");
    By email = By.id("userEmail");
    By genderMale = By.xpath("//label[text()='Male']");
    By mobile = By.id("userNumber");
    By dobField = By.id("dateOfBirthInput");
    By subjects = By.id("subjectsInput");
    By hobbiesReading = By.xpath("//label[text()='Reading']");
    By pictureUpload = By.id("uploadPicture");
    By address = By.id("currentAddress");
    By state = By.id("react-select-3-input");
    By city = By.id("react-select-4-input");
    By submitBtn = By.id("submit");

    public void fillForm() {
        driver.findElement(firstName).sendKeys("Kayal");
        driver.findElement(lastName).sendKeys("R");
        driver.findElement(email).sendKeys("kayal@example.com");
        driver.findElement(genderMale).click();
        driver.findElement(mobile).sendKeys("9876543210");

        // Date of Birth (using direct sendKeys as shortcut)
        driver.findElement(dobField).sendKeys(Keys.CONTROL + "a");
        driver.findElement(dobField).sendKeys("30 Jul 2000");
        driver.findElement(dobField).sendKeys(Keys.ENTER);

        driver.findElement(subjects).sendKeys("Computer Science");
        driver.findElement(subjects).sendKeys(Keys.ENTER);
        driver.findElement(hobbiesReading).click();

        // Adjust path based on your local image
        driver.findElement(pictureUpload).sendKeys("C:\\Users\\YourUser\\Pictures\\photo.jpg");

        driver.findElement(address).sendKeys("Bengaluru, India");

        // Scroll to dropdowns and select state/city using Actions
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(state)).click().sendKeys("NCR").sendKeys(Keys.ENTER).perform();
        actions.moveToElement(driver.findElement(city)).click().sendKeys("Delhi").sendKeys(Keys.ENTER).perform();

        driver.findElement(submitBtn).click();
    }
}
